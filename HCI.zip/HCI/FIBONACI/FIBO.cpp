#include <iostream>
using namespace std;

int fibonacciRecursive(int n) {
    if (n < 0) {
        throw invalid_argument("Input should be a non-negative integer.");
    }
    if (n == 0) {
        return 0;
    }
    if (n == 1) {
        return 1;
    }
    return fibonacciRecursive(n - 1) + fibonacciRecursive(n - 2);
}

int main() {
    cout << fibonacciRecursive(7) << endl;  // Output: 13
    return 0;
}
