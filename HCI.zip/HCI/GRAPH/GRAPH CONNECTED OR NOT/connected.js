function isConnected(graph, n) {
    let visited = new Array(n).fill(false); // Initialize visited array
    let queue = [];                         // Queue for BFS

    // Start BFS from node 0
    visited[0] = true;
    queue.push(0);

    while (queue.length > 0) {
        let node = queue.shift(); // Dequeue the front node

        // Visit all neighbors
        for (let neighbor of graph[node]) {
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                queue.push(neighbor);
            }
        }
    }

    // Check if all nodes are visited
    for (let nodeVisited of visited) {
        if (!nodeVisited) return false;
    }
    return true;
}

// Example graph as adjacency list
let graph = [
    [1, 2],       // Node 0 is connected to 1, 2
    [0, 2],       // Node 1 is connected to 0, 2
    [0, 1, 3],    // Node 2 is connected to 0, 1, 3
    [2]           // Node 3 is connected to 2
];

let n = 4; // Number of nodes

if (isConnected(graph, n)) {
    console.log("Graph is connected");
} else {
    console.log("Graph is not connected");
}
