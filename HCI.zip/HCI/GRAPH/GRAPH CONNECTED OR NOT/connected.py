from collections import deque

def is_connected(graph, n):
    visited = [False] * n
    queue = deque([0])  # Start BFS from node 0
    visited[0] = True

    while queue:
        node = queue.popleft()
        for neighbor in graph[node]:
            if not visited[neighbor]:
                visited[neighbor] = True
                queue.append(neighbor)

    # Check if all nodes are visited
    return all(visited)

# Example graph
graph = {
    0: [1, 2],
    1: [0, 2],
    2: [0, 1, 3],
    3: [2]
}
n = 4  # Number of nodes

# Output result
print("Graph is connected:", is_connected(graph, n))
