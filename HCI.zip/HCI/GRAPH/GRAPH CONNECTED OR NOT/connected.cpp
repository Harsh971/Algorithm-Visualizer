#include <iostream>
#include <vector>
#include <queue>

using namespace std;

bool isConnected(vector<vector<int>> &graph, int n) {
    vector<bool> visited(n, false);  // Initialize visited array
    queue<int> q;                    // Queue for BFS

    // Start BFS from node 0
    visited[0] = true;
    q.push(0);

    while (!q.empty()) {
        int node = q.front();
        q.pop();

        // Visit all neighbors
        for (int neighbor : graph[node]) {
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                q.push(neighbor);
            }
        }
    }

    // Check if all nodes are visited
    for (bool nodeVisited : visited) {
        if (!nodeVisited) return false;
    }
    return true;
}

int main() {
    // Example graph as adjacency list
    vector<vector<int>> graph = {
        {1, 2},     // Node 0 is connected to 1, 2
        {0, 2},     // Node 1 is connected to 0, 2
        {0, 1, 3},  // Node 2 is connected to 0, 1, 3
        {2}         // Node 3 is connected to 2
    };

    int n = 4;  // Number of nodes

    if (isConnected(graph, n)) {
        cout << "Graph is connected" << endl;
    } else {
        cout << "Graph is not connected" << endl;
    }

    return 0;
}
