#include <iostream>
#include <vector>

void dfs(int node, const std::vector<std::vector<int>>& adjList, std::vector<bool>& visited) {
    std::cout << node << " ";
    visited[node] = true;

    for (int neighbor : adjList[node]) {
        if (!visited[neighbor]) {
            dfs(neighbor, adjList, visited);
        }
    }
}

int main() {
    int vertices = 5;
    std::vector<std::vector<int>> adjList(vertices);
    adjList[0] = {1, 2};
    adjList[1] = {0, 3, 4};
    adjList[2] = {0};
    adjList[3] = {1, 4};
    adjList[4] = {1, 3};

    std::vector<bool> visited(vertices, false);
    std::cout << "DFS traversal starting from node 0: ";
    dfs(0, adjList, visited);

    return 0;
}
