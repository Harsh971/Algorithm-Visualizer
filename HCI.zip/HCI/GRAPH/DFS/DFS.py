def dfs(node, adjList, visited):
    print(node, end=" ")
    visited[node] = True

    for neighbor in adjList[node]:
        if not visited[neighbor]:
            dfs(neighbor, adjList, visited)

# Example usage
vertices = 5
adjList = [[] for _ in range(vertices)]
adjList[0] = [1, 2]
adjList[1] = [0, 3, 4]
adjList[2] = [0]
adjList[3] = [1, 4]
adjList[4] = [1, 3]

visited = [False] * vertices
print("DFS traversal starting from node 0: ", end="")
dfs(0, adjList, visited)
