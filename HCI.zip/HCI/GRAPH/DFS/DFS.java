import java.util.*;

class Graph {
    private LinkedList<Integer>[] adjList;

    Graph(int vertices) {
        adjList = new LinkedList[vertices];
        for (int i = 0; i < vertices; i++) {
            adjList[i] = new LinkedList<>();
        }
    }

    void addEdge(int v, int w) {
        adjList[v].add(w);
        adjList[w].add(v);  // For undirected graph
    }

    void dfs(int node, boolean[] visited) {
        System.out.print(node + " ");
        visited[node] = true;

        for (int neighbor : adjList[node]) {
            if (!visited[neighbor]) {
                dfs(neighbor, visited);
            }
        }
    }

    public static void main(String[] args) {
        Graph g = new Graph(5);
        g.addEdge(0, 1);
        g.addEdge(0, 2);
        g.addEdge(1, 3);
        g.addEdge(1, 4);
        g.addEdge(3, 4);

        boolean[] visited = new boolean[5];
        System.out.print("DFS traversal starting from node 0: ");
        g.dfs(0, visited);
    }
}
