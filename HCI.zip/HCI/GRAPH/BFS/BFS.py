from collections import deque

def bfs(start, adjList):
    visited = [False] * len(adjList)
    queue = deque([start])
    visited[start] = True

    while queue:
        node = queue.popleft()
        print(node, end=" ")

        for neighbor in adjList[node]:
            if not visited[neighbor]:
                visited[neighbor] = True
                queue.append(neighbor)
    print()

# Example usage
vertices = 6
adjList = [[] for _ in range(vertices)]
adjList[0] = [1, 2]
adjList[1] = [0, 3, 4]
adjList[2] = [0, 4]
adjList[3] = [1, 5]
adjList[4] = [1, 2, 5]
adjList[5] = [3, 4]

print("BFS traversal starting from node 0: ", end="")
bfs(0, adjList)
