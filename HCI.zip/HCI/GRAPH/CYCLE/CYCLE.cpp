#include <iostream>
#include <vector>
using namespace std;

// Using DFS to detect cycle in an undirected graph

bool dfs(int v, vector<int> adj[], vector<bool>& visited, int parent) {
    visited[v] = true;
    for (int neighbor : adj[v]) {
        if (!visited[neighbor]) {
            if (dfs(neighbor, adj, visited, v)) {
                return true;
            }
        } else if (neighbor != parent) {
            return true;  // A back edge found
        }
    }
    return false;
}

bool detectCycleGraph(int vertices, vector<pair<int, int>>& edges) {
    vector<int> adj[vertices];
    
    // Build adjacency list
    for (auto& edge : edges) {
        adj[edge.first].push_back(edge.second);
        adj[edge.second].push_back(edge.first);
    }

    vector<bool> visited(vertices, false);
    
    // Call DFS for all vertices
    for (int i = 0; i < vertices; i++) {
        if (!visited[i]) {
            if (dfs(i, adj, visited, -1)) {
                return true;  // Cycle detected
            }
        }
    }
    return false;  // No cycle detected
}

int main() {
    int vertices = 4;
    vector<pair<int, int>> edges = {{0, 1}, {1, 2}, {2, 3}, {3, 0}}; // This forms a cycle (0-1-2-3-0)
    cout << "Cycle detected: " << detectCycleGraph(vertices, edges) << endl;
    return 0;
}
