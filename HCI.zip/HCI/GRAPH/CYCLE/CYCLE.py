# Using DFS to detect cycle in an undirected graph

def dfs(v, adj, visited, parent):
    visited[v] = True
    for neighbor in adj[v]:
        if not visited[neighbor]:
            if dfs(neighbor, adj, visited, v):
                return True
        elif parent != neighbor:  # A back edge found
            return True
    return False

def detect_cycle_graph(vertices, edges):
    adj = [[] for _ in range(vertices)]
    
    # Build adjacency list
    for edge in edges:
        u, v = edge
        adj[u].append(v)
        adj[v].append(u)
    
    visited = [False] * vertices
    
    # Call DFS for all vertices
    for i in range(vertices):
        if not visited[i]:
            if dfs(i, adj, visited, -1):
                return True  # Cycle detected
    return False  # No cycle detected

# Example graph
vertices = 4
edges = [(0, 1), (1, 2), (2, 3), (3, 0)]  # This forms a cycle (0-1-2-3-0)
print("Cycle detected:", detect_cycle_graph(vertices, edges))
