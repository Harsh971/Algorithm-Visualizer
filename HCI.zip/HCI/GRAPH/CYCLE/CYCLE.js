// Using DFS to detect cycle in an undirected graph

function dfs(v, adj, visited, parent) {
    visited[v] = true;
    for (let neighbor of adj[v]) {
        if (!visited[neighbor]) {
            if (dfs(neighbor, adj, visited, v)) {
                return true;
            }
        } else if (parent !== neighbor) {  // A back edge found
            return true;
        }
    }
    return false;
}

function detectCycleGraph(vertices, edges) {
    let adj = Array.from({ length: vertices }, () => []);
    
    // Build adjacency list
    for (let [u, v] of edges) {
        adj[u].push(v);
        adj[v].push(u);
    }

    let visited = Array(vertices).fill(false);
    
    // Call DFS for all vertices
    for (let i = 0; i < vertices; i++) {
        if (!visited[i]) {
            if (dfs(i, adj, visited, -1)) {
                return true;  // Cycle detected
            }
        }
    }
    return false;  // No cycle detected
}

// Example graph
let vertices = 4;
let edges = [[0, 1], [1, 2], [2, 3], [3, 0]];  // This forms a cycle (0-1-2-3-0)
console.log("Cycle detected:", detectCycleGraph(vertices, edges));
