class TreeNode:
    def __init__(self, value=0, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

def find_min(node):
    while node.left is not None:
        node = node.left
    return node

def delete_node(root, key):
    if root is None:
        return root

    # Recur down the tree
    if key < root.value:
        root.left = delete_node(root.left, key)
    elif key > root.value:
        root.right = delete_node(root.right, key)
    else:
        # Node with one child or no child
        if root.left is None:
            return root.right
        elif root.right is None:
            return root.left

        # Node with two children: Get the inorder successor
        temp = find_min(root.right)
        root.value = temp.value
        root.right = delete_node(root.right, temp.value)

    return root

# Example usage
if __name__ == "__main__":
    # Creating a sample BST
    root = TreeNode(10)
    root.left = TreeNode(5)
    root.right = TreeNode(15)
    root.left.left = TreeNode(2)
    root.left.right = TreeNode(7)
    root.right.right = TreeNode(20)

    # Delete nodes
    root = delete_node(root, 2)    # Case 1: No child
    root = delete_node(root, 15)   # Case 2: One child
    root = delete_node(root, 10)   # Case 3: Two children
