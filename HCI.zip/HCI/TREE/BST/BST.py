class TreeNode:
    def __init__(self, value=0, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

def is_bst(node, min_val=float('-inf'), max_val=float('inf')):
    """
    Check if a binary tree is a BST.

    Parameters:
    node (TreeNode): The root of the binary tree.
    min_val (float): Minimum allowable value for the current node.
    max_val (float): Maximum allowable value for the current node.

    Returns:
    bool: True if the tree is a BST, False otherwise.
    """
    if node is None:
        return True

    if not (min_val < node.value < max_val):
        return False

    # Recursively check left and right subtrees
    return is_bst(node.left, min_val, node.value) and is_bst(node.right, node.value, max_val)

# Example usage
if __name__ == "__main__":
    # Creating a sample BST
    root = TreeNode(10)
    root.left = TreeNode(5)
    root.right = TreeNode(15)
    root.left.left = TreeNode(2)
    root.left.right = TreeNode(7)
    root.right.right = TreeNode(20)

    print("Is BST:", is_bst(root))  # Output: True
