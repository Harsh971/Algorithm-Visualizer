#include <iostream>
#include <climits>
using namespace std;

class TreeNode {
public:
    int value;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) {
        value = val;
        left = right = nullptr;
    }
};

bool isBST(TreeNode* node, int minVal, int maxVal) {
    if (node == nullptr) {
        return true;
    }

    if (node->value <= minVal || node->value >= maxVal) {
        return false;
    }

    // Recursively check left and right subtrees
    return isBST(node->left, minVal, node->value) && isBST(node->right, node->value, maxVal);
}

int main() {
    // Creating a sample BST
    TreeNode* root = new TreeNode(10);
    root->left = new TreeNode(5);
    root->right = new TreeNode(15);
    root->left->left = new TreeNode(2);
    root->left->right = new TreeNode(7);
    root->right->right = new TreeNode(20);

    cout << "Is BST: " << isBST(root, INT_MIN, INT_MAX) << endl;  // Output: 1 (True)
    return 0;
}
