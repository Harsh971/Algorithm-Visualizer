#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Edge {
    int src, dest, weight;
};

// Comparator to sort edges by weight
bool compare(Edge a, Edge b) {
    return a.weight < b.weight;
}

// Find function for Union-Find
int findParent(int v, vector<int> &parent) {
    if (v == parent[v]) return v;
    return parent[v] = findParent(parent[v], parent); // Path compression
}

// Union function for Union-Find
void unionSet(int u, int v, vector<int> &parent, vector<int> &rank) {
    u = findParent(u, parent);
    v = findParent(v, parent);

    if (rank[u] < rank[v]) {
        parent[u] = v;
    } else if (rank[u] > rank[v]) {
        parent[v] = u;
    } else {
        parent[v] = u;
        rank[u]++;
    }
}

void kruskalMST(vector<Edge> &edges, int V) {
    sort(edges.begin(), edges.end(), compare); // Sort edges by weight

    vector<int> parent(V);
    vector<int> rank(V, 0);

    for (int i = 0; i < V; i++) parent[i] = i; // Initialize Union-Find

    vector<Edge> mst; // Store the MST edges
    int mstWeight = 0;

    for (Edge &edge : edges) {
        int u = findParent(edge.src, parent);
        int v = findParent(edge.dest, parent);

        // If u and v are in different sets, add edge to MST
        if (u != v) {
            mst.push_back(edge);
            mstWeight += edge.weight;
            unionSet(u, v, parent, rank);
        }
    }

    // Print the MST
    cout << "Edges in MST:\n";
    for (Edge &edge : mst) {
        cout << edge.src << " - " << edge.dest << " : " << edge.weight << "\n";
    }
    cout << "Total weight of MST: " << mstWeight << endl;
}

int main() {
    int V = 4; // Number of vertices
    vector<Edge> edges = {
        {0, 1, 10},
        {0, 2, 6},
        {0, 3, 5},
        {1, 3, 15},
        {2, 3, 4}
    };

    kruskalMST(edges, V);

    return 0;
}
