class Edge {
    constructor(src, dest, weight) {
        this.src = src;
        this.dest = dest;
        this.weight = weight;
    }
}

function findParent(v, parent) {
    if (v !== parent[v]) {
        parent[v] = findParent(parent[v], parent); // Path compression
    }
    return parent[v];
}

function unionSets(u, v, parent, rank) {
    let rootU = findParent(u, parent);
    let rootV = findParent(v, parent);

    if (rank[rootU] < rank[rootV]) {
        parent[rootU] = rootV;
    } else if (rank[rootU] > rank[rootV]) {
        parent[rootV] = rootU;
    } else {
        parent[rootV] = rootU;
        rank[rootU]++;
    }
}

function kruskalMST(vertices, edges) {
    edges.sort((a, b) => a.weight - b.weight); // Sort edges by weight
    const parent = Array.from({ length: vertices }, (_, i) => i);
    const rank = Array(vertices).fill(0);
    const mst = [];
    let mstWeight = 0;

    for (let edge of edges) {
        const { src, dest, weight } = edge;

        if (findParent(src, parent) !== findParent(dest, parent)) { // If no cycle
            mst.push(edge);
            mstWeight += weight;
            unionSets(src, dest, parent, rank);
        }
    }

    // Print MST
    console.log("Edges in MST:");
    mst.forEach(({ src, dest, weight }) => {
        console.log(`${src} -- ${dest} (weight: ${weight})`);
    });
    console.log(`Total weight of MST: ${mstWeight}`);
}

// Example Graph
const vertices = 4;
const edges = [
    new Edge(0, 1, 10),
    new Edge(0, 2, 6),
    new Edge(0, 3, 5),
    new Edge(1, 3, 15),
    new Edge(2, 3, 4)
];

kruskalMST(vertices, edges);
