#include <iostream>
using namespace std;

class TreeNode {
public:
    int value;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) {
        value = val;
        left = right = nullptr;
    }
};

void inOrderTraversal(TreeNode* root) {
    if (root == nullptr) {
        return;
    }

    // Traverse the left subtree
    inOrderTraversal(root->left);
    
    // Process the current node
    cout << root->value << " ";
    
    // Traverse the right subtree
    inOrderTraversal(root->right);
}

int main() {
    // Creating a simple binary tree
    TreeNode* root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);

    cout << "In-order traversal: ";
    inOrderTraversal(root);  // Output: 4 2 5 1 3
    return 0;
}
