class TreeNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

def in_order_traversal(root):
    """
    Perform in-order traversal of a binary tree.

    Parameters:
    root (TreeNode): The root node of the binary tree.

    Returns:
    List[int]: List of values in in-order traversal.
    """
    if root is None:
        return []
    
    # Traverse the left subtree
    result = in_order_traversal(root.left)
    
    # Process the current node
    result.append(root.value)
    
    # Traverse the right subtree
    result.extend(in_order_traversal(root.right))
    
    return result

# Example usage
if __name__ == "__main__":
    # Creating a simple binary tree
    root = TreeNode(1)
    root.left = TreeNode(2)
    root.right = TreeNode(3)
    root.left.left = TreeNode(4)
    root.left.right = TreeNode(5)

    result = in_order_traversal(root)
    print("In-order traversal:", result)  # Output: [4, 2, 5, 1, 3]
