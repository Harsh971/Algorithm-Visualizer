class TreeNode {
    int value;
    TreeNode left, right;

    TreeNode(int value) {
        this.value = value;
        left = right = null;
    }
}

public class InOrderTraversal {

    public static void inOrderTraversal(TreeNode root) {
        if (root == null) {
            return;
        }
        
        // Traverse the left subtree
        inOrderTraversal(root.left);
        
        // Process the current node
        System.out.print(root.value + " ");
        
        // Traverse the right subtree
        inOrderTraversal(root.right);
    }

    public static void main(String[] args) {
        // Creating a simple binary tree
        TreeNode root = new TreeNode(1);
        root.left = new TreeNode(2);
        root.right = new TreeNode(3);
        root.left.left = new TreeNode(4);
        root.left.right = new TreeNode(5);

        System.out.print("In-order traversal: ");
        inOrderTraversal(root);  // Output: 4 2 5 1 3
    }
}
