#include <iostream>
using namespace std;

class TreeNode {
public:
    int value;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) {
        value = val;
        left = right = nullptr;
    }
};

int countNodes(TreeNode* root) {
    if (root == nullptr) {
        return 0;
    }

    // Recursively count nodes in left and right subtrees
    int leftCount = countNodes(root->left);
    int rightCount = countNodes(root->right);

    // Return total count (left + right + root)
    return leftCount + rightCount + 1;
}

int main() {
    // Creating a sample binary tree
    TreeNode* root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);

    cout << "Total nodes: " << countNodes(root) << endl;  // Output: 5
    return 0;
}
