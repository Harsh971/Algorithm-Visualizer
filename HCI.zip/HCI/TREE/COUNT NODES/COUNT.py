class TreeNode:
    def __init__(self, value=0, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

def count_nodes(root):
    """
    Count the total number of nodes in a binary tree.

    Parameters:
    root (TreeNode): The root node of the binary tree.

    Returns:
    int: Total number of nodes in the tree.
    """
    if root is None:
        return 0
    
    # Recursively count nodes in the left and right subtrees
    left_count = count_nodes(root.left)
    right_count = count_nodes(root.right)
    
    # Return total count (left + right + root)
    return left_count + right_count + 1

# Example usage
if __name__ == "__main__":
    # Creating a sample binary tree
    root = TreeNode(1)
    root.left = TreeNode(2)
    root.right = TreeNode(3)
    root.left.left = TreeNode(4)
    root.left.right = TreeNode(5)

    print("Total nodes:", count_nodes(root))  # Output: 5
