class TreeNode {
    int value;
    TreeNode left, right;

    TreeNode(int value) {
        this.value = value;
        left = right = null;
    }
}

public class CountNodes {

    public static int countNodes(TreeNode root) {
        if (root == null) {
            return 0;
        }
        
        // Recursively count nodes in left and right subtrees
        int leftCount = countNodes(root.left);
        int rightCount = countNodes(root.right);
        
        // Return total count (left + right + root)
        return leftCount + rightCount + 1;
    }

    public static void main(String[] args) {
        // Creating a sample binary tree
        TreeNode root = new TreeNode(1);
        root.left = new TreeNode(2);
        root.right = new TreeNode(3);
        root.left.left = new TreeNode(4);
        root.left.right = new TreeNode(5);

        System.out.println("Total nodes: " + countNodes(root));  // Output: 5
    }
}
