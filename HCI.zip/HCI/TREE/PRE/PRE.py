class TreeNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

def pre_order_traversal(root):
    """
    Perform pre-order traversal of a binary tree.

    Parameters:
    root (TreeNode): The root node of the binary tree.

    Returns:
    List[int]: List of values in pre-order traversal.
    """
    if root is None:
        return []
    
    # Process the current node
    result = [root.value]
    
    # Traverse the left subtree
    result.extend(pre_order_traversal(root.left))
    
    # Traverse the right subtree
    result.extend(pre_order_traversal(root.right))
    
    return result

# Example usage
if __name__ == "__main__":
    # Creating a simple binary tree
    root = TreeNode(1)
    root.left = TreeNode(2)
    root.right = TreeNode(3)
    root.left.left = TreeNode(4)
    root.left.right = TreeNode(5)

    result = pre_order_traversal(root)
    print("Pre-order traversal:", result)  # Output: [1, 2, 4, 5, 3]
