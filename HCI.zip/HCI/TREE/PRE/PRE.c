#include <iostream>
using namespace std;

class TreeNode {
public:
    int value;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) {
        value = val;
        left = right = nullptr;
    }
};

void preOrderTraversal(TreeNode* root) {
    if (root == nullptr) {
        return;
    }

    // Process the current node
    cout << root->value << " ";

    // Traverse the left subtree
    preOrderTraversal(root->left);
    
    // Traverse the right subtree
    preOrderTraversal(root->right);
}

int main() {
    // Creating a simple binary tree
    TreeNode* root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);

    cout << "Pre-order traversal: ";
    preOrderTraversal(root);  // Output: 1 2 4 5 3
    return 0;
}
