class TreeNode {
    int value;
    TreeNode left, right;

    TreeNode(int value) {
        this.value = value;
        left = right = null;
    }
}

public class PreOrderTraversal {

    public static void preOrderTraversal(TreeNode root) {
        if (root == null) {
            return;
        }
        
        // Process the current node
        System.out.print(root.value + " ");
        
        // Traverse the left subtree
        preOrderTraversal(root.left);
        
        // Traverse the right subtree
        preOrderTraversal(root.right);
    }

    public static void main(String[] args) {
        // Creating a simple binary tree
        TreeNode root = new TreeNode(1);
        root.left = new TreeNode(2);
        root.right = new TreeNode(3);
        root.left.left = new TreeNode(4);
        root.left.right = new TreeNode(5);

        System.out.print("Pre-order traversal: ");
        preOrderTraversal(root);  // Output: 1 2 4 5 3
    }
}
