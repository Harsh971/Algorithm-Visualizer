class TreeNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

def post_order_traversal(root):
    """
    Perform post-order traversal of a binary tree.

    Parameters:
    root (TreeNode): The root node of the binary tree.

    Returns:
    List[int]: List of values in post-order traversal.
    """
    if root is None:
        return []
    
    # Traverse the left subtree
    result = post_order_traversal(root.left)
    
    # Traverse the right subtree
    result.extend(post_order_traversal(root.right))
    
    # Process the current node
    result.append(root.value)
    
    return result

# Example usage
if __name__ == "__main__":
    # Creating a simple binary tree
    root = TreeNode(1)
    root.left = TreeNode(2)
    root.right = TreeNode(3)
    root.left.left = TreeNode(4)
    root.left.right = TreeNode(5)

    result = post_order_traversal(root)
    print("Post-order traversal:", result)  # Output: [4, 5, 2, 3, 1]
