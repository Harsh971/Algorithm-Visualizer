class TreeNode {
    int value;
    TreeNode left, right;

    TreeNode(int value) {
        this.value = value;
        left = right = null;
    }
}

public class PostOrderTraversal {

    public static void postOrderTraversal(TreeNode root) {
        if (root == null) {
            return;
        }
        
        // Traverse the left subtree
        postOrderTraversal(root.left);
        
        // Traverse the right subtree
        postOrderTraversal(root.right);
        
        // Process the current node
        System.out.print(root.value + " ");
    }

    public static void main(String[] args) {
        // Creating a simple binary tree
        TreeNode root = new TreeNode(1);
        root.left = new TreeNode(2);
        root.right = new TreeNode(3);
        root.left.left = new TreeNode(4);
        root.left.right = new TreeNode(5);

        System.out.print("Post-order traversal: ");
        postOrderTraversal(root);  // Output: 4 5 2 3 1
    }
}
