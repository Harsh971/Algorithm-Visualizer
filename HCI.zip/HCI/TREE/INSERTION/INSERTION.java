class TreeNode {
    int value;
    TreeNode left, right;

    TreeNode(int value) {
        this.value = value;
        left = right = null;
    }
}

public class InsertBST {

    public static TreeNode insert(TreeNode root, int value) {
        if (root == null) {
            return new TreeNode(value);
        }

        if (value < root.value) {
            root.left = insert(root.left, value);
        } else {
            root.right = insert(root.right, value);
        }

        return root;
    }

    public static void main(String[] args) {
        // Creating a sample BST
        TreeNode root = new TreeNode(10);
        root = insert(root, 5);
        root = insert(root, 15);
        root = insert(root, 2);
        root = insert(root, 7);

        // Insert 6 into the BST
        root = insert(root, 6);
    }
}
