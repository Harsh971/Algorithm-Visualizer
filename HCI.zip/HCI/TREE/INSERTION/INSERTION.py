class TreeNode:
    def __init__(self, value=0, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

def insert(root, value):
    if root is None:
        return TreeNode(value)
    
    if value < root.value:
        root.left = insert(root.left, value)
    else:
        root.right = insert(root.right, value)
    
    return root

# Example usage
if __name__ == "__main__":
    # Creating a sample BST
    root = TreeNode(10)
    root = insert(root, 5)
    root = insert(root, 15)
    root = insert(root, 2)
    root = insert(root, 7)
    
    # Insert 6 into the BST
    root = insert(root, 6)
