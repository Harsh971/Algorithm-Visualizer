class TreeNode:
    def __init__(self, value=0, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

def max_depth(root):
    """
    Find the maximum depth of a binary tree.

    Parameters:
    root (TreeNode): The root node of the binary tree.

    Returns:
    int: Maximum depth of the tree.
    """
    if root is None:
        return 0
    
    # Recursively find the maximum depth of left and right subtrees
    left_depth = max_depth(root.left)
    right_depth = max_depth(root.right)
    
    # Return the greater of the two depths plus 1
    return max(left_depth, right_depth) + 1

# Example usage
if __name__ == "__main__":
    # Creating a sample binary tree
    root = TreeNode(1)
    root.left = TreeNode(2)
    root.right = TreeNode(3)
    root.left.left = TreeNode(4)
    root.left.right = TreeNode(5)
    root.left.left.left = TreeNode(6)

    print("Max depth:", max_depth(root))  # Output: 4
