#include <iostream>
using namespace std;

/**
 * Perform bitwise AND operation on two integers.
 *
 * @param a First integer
 * @param b Second integer
 * @return Result of a AND b
 */
int bitwiseAnd(int a, int b) {
    return a & b;
}

int main() {
    int A = 13;  // Binary: 1101
    int B = 11;  // Binary: 1011
    int result = bitwiseAnd(A, B);
    cout << "The result of " << A << " AND " << B << " is: " << result << endl;  // Output: 9
    return 0;
}
