def bitwise_and(a: int, b: int) -> int:
    """
    Perform bitwise AND operation on two integers.

    Parameters:
    a (int): First integer
    b (int): Second integer

    Returns:
    int: Result of a AND b
    """
    return a & b

# Example usage
A = 13  # Binary: 1101
B = 11  # Binary: 1011
result = bitwise_and(A, B)
print(f"The result of {A} AND {B} is: {result}")  # Output: 9
