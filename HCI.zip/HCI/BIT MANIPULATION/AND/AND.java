public class BitwiseAND {

    /**
     * Perform bitwise AND operation on two integers.
     *
     * @param a First integer
     * @param b Second integer
     * @return Result of a AND b
     */
    public static int bitwiseAnd(int a, int b) {
        return a & b;
    }

    public static void main(String[] args) {
        int A = 13;  // Binary: 1101
        int B = 11;  // Binary: 1011
        int result = bitwiseAnd(A, B);
        System.out.println("The result of " + A + " AND " + B + " is: " + result);  // Output: 9
    }
}
