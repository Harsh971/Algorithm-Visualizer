#include <iostream>
using namespace std;

/**
 * Perform bitwise OR operation on two integers.
 *
 * @param a First integer
 * @param b Second integer
 * @return Result of a OR b
 */
int bitwiseOr(int a, int b) {
    return a | b;
}

int main() {
    int A = 13;  // Binary: 1101
    int B = 11;  // Binary: 1011
    int result = bitwiseOr(A, B);
    cout << "The result of " << A << " OR " << B << " is: " << result << endl;  // Output: 15
    return 0;
}
