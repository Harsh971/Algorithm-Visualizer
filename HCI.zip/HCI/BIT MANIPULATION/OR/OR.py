def bitwise_or(a: int, b: int) -> int:
    """
    Perform bitwise OR operation on two integers.

    Parameters:
    a (int): First integer
    b (int): Second integer

    Returns:
    int: Result of a OR b
    """
    return a | b

# Example usage
A = 13  # Binary: 1101
B = 11  # Binary: 1011
result = bitwise_or(A, B)
print(f"The result of {A} OR {B} is: {result}")  # Output: 15
