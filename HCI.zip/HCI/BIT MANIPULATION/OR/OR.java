public class BitwiseOR {

    /**
     * Perform bitwise OR operation on two integers.
     *
     * @param a First integer
     * @param b Second integer
     * @return Result of a OR b
     */
    public static int bitwiseOr(int a, int b) {
        return a | b;
    }

    public static void main(String[] args) {
        int A = 13;  // Binary: 1101
        int B = 11;  // Binary: 1011
        int result = bitwiseOr(A, B);
        System.out.println("The result of " + A + " OR " + B + " is: " + result);  // Output: 15
    }
}
