def flip_kth_bit(n: int, k: int) -> int:
    """
    Flip the k-th bit of an integer n.

    Parameters:
    n (int): The integer to flip the bit in.
    k (int): The position of the bit to flip (0-indexed).

    Returns:
    int: The integer after flipping the k-th bit.
    """
    return n ^ (1 << k)

# Example usage
n = 13  # Binary: 1101
k = 2
result = flip_kth_bit(n, k)
print(f"The result of flipping the {k}-th bit of {n} is: {result}")  # Output: 9 (Binary: 1001)
