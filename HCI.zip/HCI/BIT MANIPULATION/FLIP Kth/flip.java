public class FlipKthBit {

    /**
     * Flip the k-th bit of an integer n.
     *
     * @param n The integer to flip the bit in.
     * @param k The position of the bit to flip (0-indexed).
     * @return The integer after flipping the k-th bit.
     */
    public static int flipKthBit(int n, int k) {
        return n ^ (1 << k);
    }

    public static void main(String[] args) {
        int n = 13;  // Binary: 1101
        int k = 2;
        int result = flipKthBit(n, k);
        System.out.println("The result of flipping the " + k + "-th bit of " + n + " is: " + result);  // Output: 9
    }
}
