#include <iostream>
using namespace std;

/**
 * Flip the k-th bit of an integer n.
 *
 * @param n The integer to flip the bit in.
 * @param k The position of the bit to flip (0-indexed).
 * @return The integer after flipping the k-th bit.
 */
int flipKthBit(int n, int k) {
    return n ^ (1 << k);
}

int main() {
    int n = 13;  // Binary: 1101
    int k = 2;
    int result = flipKthBit(n, k);
    cout << "The result of flipping the " << k << "-th bit of " << n << " is: " << result << endl;  // Output: 9
    return 0;
}
