public class FindKthBit {

    /**
     * Find the k-th bit of an integer n.
     *
     * @param n The integer to extract the bit from.
     * @param k The position of the bit to extract (0-indexed).
     * @return The value of the k-th bit (0 or 1).
     */
    public static int findKthBit(int n, int k) {
        return (n >> k) & 1;
    }

    public static void main(String[] args) {
        int n = 13;  // Binary: 1101
        int k = 2;
        int result = findKthBit(n, k);
        System.out.println("The " + k + "-th bit of " + n + " is: " + result);  // Output: 1
    }
}
