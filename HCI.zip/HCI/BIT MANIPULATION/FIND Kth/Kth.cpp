#include <iostream>
using namespace std;

/**
 * Find the k-th bit of an integer n.
 *
 * @param n The integer to extract the bit from.
 * @param k The position of the bit to extract (0-indexed).
 * @return The value of the k-th bit (0 or 1).
 */
int findKthBit(int n, int k) {
    return (n >> k) & 1;
}

int main() {
    int n = 13;  // Binary: 1101
    int k = 2;
    int result = findKthBit(n, k);
    cout << "The " << k << "-th bit of " << n << " is: " << result << endl;  // Output: 1
    return 0;
}
