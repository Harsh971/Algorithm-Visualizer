def find_kth_bit(n: int, k: int) -> int:
    """
    Find the k-th bit of an integer n.

    Parameters:
    n (int): The integer to extract the bit from.
    k (int): The position of the bit to extract (0-indexed).

    Returns:
    int: The value of the k-th bit (0 or 1).
    """
    return (n >> k) & 1

# Example usage
n = 13  # Binary: 1101
k = 2
result = find_kth_bit(n, k)
print(f"The {k}-th bit of {n} is: {result}")  # Output: 1 (the 2nd bit is 1)
