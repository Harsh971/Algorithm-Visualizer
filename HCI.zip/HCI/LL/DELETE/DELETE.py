class Node:
    def __init__(self, value):
        self.value = value
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, value):
        new_node = Node(value)
        if not self.head:
            self.head = new_node
            return
        last = self.head
        while last.next:
            last = last.next
        last.next = new_node

    def delete_at_position(self, position):
        # Case 1: List is empty
        if not self.head:
            print("List is empty.")
            return

        # Case 2: Deleting the head node
        if position == 0:
            self.head = self.head.next
            return

        # Traverse to the node just before the position
        current = self.head
        for _ in range(position - 1):
            if not current.next:  # If we reach the end before the desired position
                print("Position exceeds the length of the list.")
                return
            current = current.next

        # Case 3: Deleting beyond list length
        if not current.next:
            print("Position exceeds the length of the list.")
            return

        # Delete the node at the specified position
        current.next = current.next.next

    def display(self):
        current = self.head
        while current:
            print(current.value, end=" -> ")
            current = current.next
        print("NULL")
