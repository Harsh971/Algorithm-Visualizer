class Node:
    def __init__(self, value):
        self.value = value
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, value):
        new_node = Node(value)
        if not self.head:
            self.head = new_node
            return
        last = self.head
        while last.next:
            last = last.next
        last.next = new_node

    def reverse(self):
        prev = None
        current = self.head
        while current:
            next_node = current.next  # Store next node
            current.next = prev       # Reverse the link
            prev = current            # Move prev to current
            current = next_node       # Move to the next node
        self.head = prev             # Update the head to the new front

    def traverse(self):
        current = self.head
        while current:
            print(current.value, end=' -> ')
            current = current.next
        print("NULL")

# Example usage
if __name__ == "__main__":
    linked_list = LinkedList()
    linked_list.append(10)
    linked_list.append(20)
    linked_list.append(30)
    linked_list.append(40)
    
    print("Original List:")
    linked_list.traverse()  # Output: 10 -> 20 -> 30 -> 40 -> NULL
    
    linked_list.reverse()
    
    print("Reversed List:")
    linked_list.traverse()  # Output: 40 -> 30 -> 20 -> 10 -> NULL
