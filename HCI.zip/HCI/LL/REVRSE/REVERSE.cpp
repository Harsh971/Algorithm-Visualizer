#include <iostream>
using namespace std;

class Node {
public:
    int value;
    Node* next;

    Node(int val) {
        value = val;
        next = nullptr;
    }
};

class LinkedList {
public:
    Node* head;

    LinkedList() {
        head = nullptr;
    }

    void append(int value) {
        Node* newNode = new Node(value);
        if (head == nullptr) {
            head = newNode;
            return;
        }
        Node* last = head;
        while (last->next != nullptr) {
            last = last->next;
        }
        last->next = newNode;
    }

    void reverse() {
        Node* prev = nullptr;
        Node* current = head;
        while (current != nullptr) {
            Node* nextNode = current->next; // Store next node
            current->next = prev;            // Reverse the link
            prev = current;                  // Move prev to current
            current = nextNode;              // Move to the next node
        }
        head = prev; // Update the head to the new front
    }

    void traverse() {
        Node* current = head;
        while (current != nullptr) {
            cout << current->value << " -> ";
            current = current->next;
        }
        cout << "NULL" << endl;
    }
};

int main() {
    LinkedList linkedList;
    linkedList.append(10);
    linkedList.append(20);
    linkedList.append(30);
    linkedList.append(40);
    
    cout << "Original List:" << endl;
    linkedList.traverse();  // Output: 10 -> 20 -> 30 -> 40 -> NULL
    
    linkedList.reverse();
    
    cout << "Reversed List:" << endl;
    linkedList.traverse();  // Output: 40 -> 30 -> 20 -> 10 -> NULL
    
    return 0;
}
