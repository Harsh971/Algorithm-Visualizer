class Node {
    int value;
    Node next;

    Node(int value) {
        this.value = value;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    public void append(int value) {
        Node newNode = new Node(value);
        if (head == null) {
            head = newNode;
            return;
        }
        Node last = head;
        while (last.next != null) {
            last = last.next;
        }
        last.next = newNode;
    }

    public void reverse() {
        Node prev = null;
        Node current = head;
        while (current != null) {
            Node nextNode = current.next; // Store next node
            current.next = prev;           // Reverse the link
            prev = current;                // Move prev to current
            current = nextNode;            // Move to the next node
        }
        head = prev; // Update the head to the new front
    }

    public void traverse() {
        Node current = head;
        while (current != null) {
            System.out.print(current.value + " -> ");
            current = current.next;
        }
        System.out.println("NULL");
    }

    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.append(10);
        linkedList.append(20);
        linkedList.append(30);
        linkedList.append(40);
        
        System.out.println("Original List:");
        linkedList.traverse();  // Output: 10 -> 20 -> 30 -> 40 -> NULL
        
        linkedList.reverse();
        
        System.out.println("Reversed List:");
        linkedList.traverse();  // Output: 40 -> 30 -> 20 -> 10 -> NULL
    }
}
