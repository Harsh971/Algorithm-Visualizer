public class LinearSearch {
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i;  // Return the index of the target
            }
        }
        return -1;  // If the target is not found
    }

    public static void main(String[] args) {
        int[] arr = {10, 23, 45, 70, 11, 15};
        int target = 70;
        System.out.println("Index of target: " + linearSearch(arr, target));  // Output: 3
    }
}
