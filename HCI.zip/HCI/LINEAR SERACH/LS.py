def linear_search(arr, target):
    for index, element in enumerate(arr):
        if element == target:
            return index  # Return the index of the target
    return -1  # If the target is not found

# Example usage
arr = [10, 23, 45, 70, 11, 15]
target = 70
print("Index of target:", linear_search(arr, target))  # Output: 3
